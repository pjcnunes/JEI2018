<!DOCTYPE html>
<?php
	$nomeCompleto = 'Nome Completo';
	$email = 'pnunes@ipg.pt';
	$emailRetype = 'pnunes@ipg.pt';
	$telemovel = '912345678';
	$escola = 'Escola';
	$ano = '10º';
	$curso = 'Engenharia Informática';
?>
<html lang="pt">
<head>
	<?php include('head.php'); ?>    
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" type="text/css" href="css/estilos_lista.css">
</head>
<body>
	<div id='pagina'>
		<div id='cabecalho'>
			<?php include('cabecalho.php'); ?>
		</div>		
		<div id='menu'>
			<?php include('menu.php'); ?>
		</div>	
		<div id='conteudo'>
		  <h1>Inscrição</h1>
      <form name='Participants' method='POST' enctype='multipart/form-data' action='Participants_proc.php'>
        <table>
          <tr>
            <th class='form'>Nome Completo</th>
            <td><input class='it2' type='text' id='NomeCompleto' name='NomeCompleto' value="<?php echo $nomeCompleto; ?>"/>*
            </td>
          </tr>
          <tr>
            <th class='form'>EMail</th>
            <td><input class='it2' type='email' id='Email' name='Email' value="<?php echo $email; ?>"/>*
            </td>
          </tr>
          <tr>
            <th class='form'>EMail-Retype</th>
            <td><input class='it2' type='email' id='EmailRetype' name='EmailRetype' value="<?php echo $emailRetype; ?>"/>*
            </td>
          </tr>
          <tr>
            <th class='form'>Telemóvel</th>
            <td><input class='it2' type='number' id='Telemovel' name='Telemovel' size='12' value="<?php echo $telemovel; ?>"/>*</td>
          </tr>
          <tr>
            <th class='form'>Escola</th>
            <td>
              <input class='it2' type='text' id='Escola' name='Escola' value="<?php echo $escola; ?>"/>*
            </td>
          </tr>
          <tr>
            <th class='form'>Ano</th>
            <td>
              <select class='it2' id='Ano' name='Ano'>
                <option <?php echo $ano=='10º'?'selected':'';?>>10º</option>
                <option <?php echo $ano=='11º'?'selected':'';?>>11º</option>
                <option <?php echo $ano=='12º'?'selected':'';?>>12º</option>
              </select>*
            </td>
          </tr>
          <tr>
            <th class='form'>Curso</th>
            <td>
              <select class='it2' id='Curso' name='Curso'">
                <option <?php echo $curso=='Engenharia Informática'?'selected':'';?>>Engenharia Informática</option>
                <option <?php echo $curso=='Cibersegurança'?'selected':'';?>>Cibersegurança</option>
				<option <?php echo $curso=='Desenvolvimento de Aplicações Informáticas'?'selected':'';?>>Desenvolvimento de Aplicações Informáticas</option>
				<option <?php echo $curso=='Infraestruturas de Cloud, Redes e Data Center'?'selected':'';?>>Infraestruturas de Cloud, Redes e Data Center</option>
				<option <?php echo $curso=='Testes de Software'?'selected':'';?>>Testes de Software</option>
	          </select>*
            </td>
          </tr>
            <tr>
              <td colspan='2' style="text-align: center;">
                 <a href="index.php"><input type='button' class="btn" value='Cancelar' /></a> 
                 <input type='submit' class="btn" value='Enviar' />
					   </td>
            </tr>
        </table>
      </form>			
		</div>
		<div id='rodape'>	
			<?php include('rodape.php'); ?>
		</div>		
	</div>	
</body>
</html>