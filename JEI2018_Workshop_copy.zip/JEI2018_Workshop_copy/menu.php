<ul>
	<li><a href="index.php">Home</a></li>
	<li><a href="Participants.php">Inscrição</a></li>
	<li><a href="Participants_lista.php">Lista de participantes</a></li>
	<li><a href="Participants_lista.php?op=C">Confirmados</a></li>
	<li><a href="Participants_lista.php?op=NC">Não confirmados</a></li>
	<li><a href="admin/login.php">Login</a></li>
</ul>
