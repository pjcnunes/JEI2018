﻿<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
//include "User_logged.php";
include "Administrator.php";

require_once 'CBaseFormValidation.php';

$link_email = 'http://www.eusouengenheiro.ipg.pt';
$_JEI = 'EUSOUENGENHEIRO';


$LINK_HOME = "http://www.jei.ipg.pt/$_JEI/index.php";
$LINK_ATRAS = htmlspecialchars("Participants.php");
$msg_voltar = "<p>Clique no botão retroceder do seu browser para voltar ao formulário.</p>";
$msg_voltar = "<br /><a style='color:#45aed6; font-size:14px;' href='$LINK_HOME'>JEI'16</a>";
$msg_logout = "<br /><a style='color:#45aed6; font-size:14px;' href='logout.php'>Logout ($Nome)</a><br />";
$msg_torneio = "<a style='color:#45aed6; font-size:14px;' href='ParticipantsList.php?SITUACAO=INSCRITOS&r=1247895'>Participantes</a><br />";

$jei = <<<_END
<p style="margin-bottom:1em;font-size: 24pt;color:#64686d;'><a class="navbar-brand" href="$link_email/">
    <span style="color:#45aed6; font-weight: 600; font-family: 'Roboto', sans-serif;">eusouengenheiro'16</a></p>
_END;

$op =0;
if (isset($_REQUEST['SITUACAO'])) {
    $situacao = CBaseFormValidation::test_input($_REQUEST['SITUACAO']) ;
    if (($situacao == 'INSCRITOS') || ($situacao == 'INSCRITOS') || ($situacao == 'INSCRITOS')) {
        $op = 1;
    }
}
if ($op == 0)
{
    echo $msg_voltar;
    return;
}
$reg = intval(CBaseFormValidation::test_input($_REQUEST['r'])) ;
// http://www.jei.ipg.pt/JEI2016/AccessRegisterList.php?SITUACAO=INSCRITOS
//http://www.jei.ipg.pt/JEI2016/AccessRegisterList.php?SITUACAO=INSCRITOS&r=1
// http://www.jei.ipg.pt/JEI2016/ParticipantsTorneioList.php?SITUACAO=INSCRITOS
//http://www.jei.ipg.pt/JEI2016/ParticipantsTorneioList.php?SITUACAO=INSCRITOS&r=1
echo $jei;
echo $msg_logout;
//echo $msg_torneio;
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta name="description" content="eusouengenheiro 2016">
    <meta name="author" content="Intituto Politécnico da Guarda">
    <title>eusouengenheiro 2016 | IPG | Ficha de Inscrição: Confirmação</title>

    <style type='text/css'>
        table {
            border-collapse: collapse;
            border: solid 1px #45aed6;
            background-color: white;
        }

        th {
            border: solid 1px #45aed6;
            text-align: center;
            color: #64686d;
            padding: 4px;
            background-color: white;
        }

        td {
            border: solid 1px #45aed6;
            text-align: left;
            padding: 4px;
            color: #8b4513;
            background-color: white;
        }

        h1 {
            font-size: 18pt;
            color: black;
            margin: 0;
            font-variant: small-caps;
            margin-bottom: 10px;
        }

        h2 {
            font-size: 14pt;
            color: black;
            margin: 0;
            margin-top: 20px;
            font-variant: small-caps;
            margin-bottom: 10px;
        }
        td.dados_dir, td.dados_dir_red, td.dados_dir_red_mais, dados_dir_red_menos {
            text-align: right;
            padding-right: 1em;
            width: 3em;
        }
        td.dados_dir_red {
           color: black;
            font-weight: bold;
           background-color: #fdef9f;
        }
        td.dados_dir_red_menos {
            color: white;
            font-weight: bold;
            background-color: orange;
        }
        td.dados_dir_red_mais {
            color: white;
            font-weight: bold;
            background-color: red;
        }

    </style>
</head>
<body>

<style type='text/css'>
  table._grafico {background-color: #FFFFFF;}

  th._grafico {
      font-size: 8pt;
      text-align: center;
      vertical-align: top;
      width: 2em;
      border: solid 1px #45aed6;
      padding: 2px;
      padding-top: 10px;
      color: #45aed6;
  }

  td._grafico {
      font-size: 8pt;
      vertical-align: bottom;
      text-align: center;
      width: 2em;
      border: solid 1px white;
      padding: 2px;
      color: #FFFFFF;
      border-bottom: solid 3px #45aed6;
  }
  	/* Engenharia Informática */
    /* Pantone Precess Cyan | 100%  #00FFFF (websafe) */ border-bottom: solid 3px #45aed6;
    /* Pantone 7542 C  #c1d6d0; | 100 */
	div._grafico{ margin-left: 10pt; margin-bottom: 5px;}

</style>

  <?php

  require_once 'DBPDOConnection.php';
  require_once 'AccessRegisterRepository.php';
  require_once 'AccessRegisterClass.php';

  require_once 'ParticipanteRepository.php';
  require_once 'UserAccountsRepository.php';
  require_once 'FolhasPresencaPDF.php';

  $participante = new ParticipanteRepository();
  $useraccount = new UserAccountsRepository();
  $acccess = new AccessRegisterRepository();


  // ---------- new 2012-11-29
  /* include('./graficos.php'); */

  function VetorMin($v) {
      $s = 0;
      $n = count($v);
      for ($j=0; $j < $n; $j++) 	{
          if ($s < $v[$j]) $s = $v[$j];
      }
      return $s;
  }
  function VetorSoma($v) {
      $s = 0;
      $n = count($v);
      for ($j=0; $j < $n; $j++) 	{
          $s += $v[$j];
      }
      return $s;
  }

  function VetorValorParaPercentagem($v) {
      $s = 0;
      $n = count($v)-1;
      $C = VetorSoma($v);
      $v2 = array();
      for ($j=0; $j < $n; $j++) 	{
          $v2[$j] = round($v[$j] * 100.0 / $C, 1);
          $s += $v2[$j];
          //echo "<p>$j $v[$j] $v2[$j] $s</p>";
      }
      $v2[$n] = round(100 - $s, 1);
      //echo "<p>$j $v2[$n] $s</p>";
      //echo count($v2);
      return $v2;
  }

  function GraficoBarras($a, $Legends, $l, $r, $pos, $unit, $th, $scale, $conv_percentagem) {

      if ($conv_percentagem)
          $a = VetorValorParaPercentagem($a);
      //$cores [] = array('brown', 'black', 'red',  'blue', 'magenta', 'navy');
      $s = "";
      $s .="<table class='_grafico'>";
      $th=1;

      $s .="<tr>";
      for ($j =$l; $j <= $r; $j++) {
          $s .="<td class='_grafico'>";
          if ($j == $pos[0])
              $cor ='green';
          else if ($j == $pos[1])
              $cor ='red';
          else if ($j == $pos[2])
              $cor ='orange';
          else
              $cor ='black';

          $s .= "<font color='$cor'>" . $a[$j] . $unit . "</font>";

          $cor = "#" . dechex(round((154875*(17+$a[$j]* $scale)) % (256*256*256)));

          $s .="<div style='height: " . number_format(($a[$j] * $scale),1) . "px; background-color: " . $cor . ";'></div>";

          $s .="</td>";
      }
      $s .="</tr>";
      if ($th) {
          $s .= "<tr>";
          for ($j=$l; $j <= $r; $j++) {
              $s .= "<th class='_grafico'>" . $Legends[$j] . "</th>";
          }
          $s .= "</tr>";
      }
      if ($th) $s .= "</table>";
      return $s;
  }


  $participante->listAllHTML();



  $data = new AccessRegisterClass();
  //$acccess->listAllHTML();
  // inscrições / vagas
  $C = 0;
  $f = 0;
  $GLabels = array();
  $GValues = array();
  $GLabelsA = array();
  $GValuesA = array();

      foreach ($result_obj_wss as $k2 => $data) {
          $inscricoes = 20;
          $LIMITE = $data->vagas - $data->vagas_reservadas;
          $hora = $data->DataHora;
          $hora = " Dia " . substr($hora, 9, 2) .'<br />' .  substr($hora, 11, 5);
          $VAGAS = $LIMITE - $inscricoes;

          if ($a===0) {
            $xLabel = "$hora <br /><br /> $Workshop <br /><br /> $Nome    ";
              $a++;
          } else {
              $xLabel = "$hora ";
          }
          $GLabels[] = $xLabel;
          $GValues[] = $LIMITE;
          $GLabels[] = "<span style='color:green;'>Ocupação";
          $GValues[] = $inscricoes + $data->vagas_reservadas;               // #############
          $GLabels[] = "<span style='color:brown;'>Vagas";
          $GValues[] = $VAGAS;

          $GLabelsA[] = $xLabel;
          $GValuesA[] = $inscricoes + $data->vagas_reservadas;

  }
  // gráfico
  $scale = 7; // VetorMin($GValues);
  $s = GraficoBarras($GValues, $GLabels, 0, count($GValues)-1, array(-1,-1,-1), ' ', 1, $scale, false);
  echo "<h1>Estado das inscrições (Confirmadas)</h1>";
  echo "<div class='_grafico'>$s</div>";
  // gráfico
  $s = GraficoBarras($GValuesA, $GLabelsA, 0, count($GValuesA)-1, array(-1,-1,-1), ' ', 1, $scale, false);
  echo "<h1><br />Inscrições (Confirmadas)</h1>";
  echo "<div class='_grafico'>$s</div>";


  echo "<br /><h1>eu sou engenheiro - Acessos</h1>";
  // acessos do dia hora a hora $data = date("Y/m/d G:i:s", time());
  $vetor_obj = $acccess->selectAccessByDifferentIPByDayHour("SUBMIT_DATE");
  $N = count($vetor_obj);
  $GLabels = array();
  $GValues = array();
  foreach($vetor_obj as $row) {
      $GLabels[] = $row->Hora;
      $GValues[] = $row->Acessos;
  }
  // gráfico
  $scale = 2.0; // VetorMin($GValues);
  $s = GraficoBarras($GValues, $GLabels, 0, count($GValues)-1, array(-1,-1,-1), ' ', 1, $scale, false);
  $data = date("d/m/Y", time());
  echo "<br><h1>Acessos do Dia: Hora a Hora ($data)</h1>";
  echo "<div class='_grafico'>$s</div>";

  // acessos dia a dia
  $vetor_obj = $acccess->selectAccessByDifferentIPByDay("SUBMIT_DATE");
  $N = count($vetor_obj);
  $GLabels = array();
  $GValues = array();
  foreach($vetor_obj as $row) {
      $GLabels[] = $row->Dia . '<br />' . $row->Mes . '<br />' . $row->Ano;
      $GValues[] = $row->Acessos;
  }
  // gráfico
  $scale = 2.0; // VetorMin($GValues);
  $s = GraficoBarras($GValues, $GLabels, 0, count($GValues)-1, array(-1,-1,-1), ' ', 1, $scale, false);
  echo "<br><h1>Acessos Dia a Dia</h1>";
  echo "<div class='_grafico'>$s</div>";

  echo "<br><h1>Lista de não confirmados</h1>";
  $participante->inscricoesNAOCONFIRMADASHTML();

  $ddd = date("Y/m/d G:i:s", time());
  echo "<br><h1>Lista de com todo os incritos ordenada por nome $ddd</h1>";
  $participante->inscricoesListaOrdenadaAll();


  $sits = array('CONFIRMADA','NAO CONFIRMADA', 'CANCELADA');
  foreach($sits as $sit) {
      $vetor_obj = $participante->selectInscricoesByDay("SUBMIT_DATE ASC", $sit);
      $GLabels = array();
      $GValues = array();
      $n=0;
      foreach ($vetor_obj as $row) {
          $GLabels[] = $row->Dia . '<br />' . $row->Mes . '<br />' . $row->Ano;
          $GValues[] = $row->Inscricoes;
          $n += $row->Inscricoes;
      }
      // gráfico
      $scale = 4.0; // VetorMin($GValues);
      $s = GraficoBarras($GValues, $GLabels, 0, count($GValues) - 1, array(-1, -1, -1), ' ', 1, $scale, false);
      echo "<br><h1>Inscritos Dia a Dia ($sit: $n)</h1>";
      echo "<div class='_grafico'>$s</div>";
  }



  // $lista_participantes [$dss->id_workshop][$dss->id_session][$datas->DataHora] []
  $pdf_all = new FolhasPresencaPDF("P", "mm", "A4");
  $t = $participante->getTtableName();
  $File_Name_All = "Presencas_All_$t.pdf";
 // echo "<p><a href='$link_email/$_JEI/tmp2/$File_Name_All '>All PDF</a></p>";
   // echo "<p><a href='./tmp2/$File_Name_All '>PDF</a></p>";

  $situacao = 'CORFIRMADA';
  $datahora ='';
  $cursos = array('Engenharia Informática', 'Programa de Engenharia Civil, Topográfica e Ambiente');
  for ($j=0; $j < count($cursos); $j++) {
      $k=$j;
      $c = $cursos[$j];
      $lista_participantes = $participante->inscricoes($c);
      echo "<h1>$c</h1>";
      echo "<table>";
      $lista_array = array();
      $i=0;
      foreach ($lista_participantes as $k => $v) {
          $N = count($v);
          $i++;
          $orador = "";
          echo "<tr><td>$i</td><td>$v->NomeCompleto</td></tr> ";
          $lista_array [] = array("$i", ' ', $v->NomeCompleto, ' ');

      }
      echo "</table>";
      $w = "_{$k}_{$situacao}_presencas.pdf";//{$dw->Workshop}
      $w = str_replace('"', '', $w);
      $w = str_replace(':', '_', $w);
      $w = str_replace('-', '_', $w);
      $w = utf8_decode($w);
      $File_Name = $w;

          $curso =  $cursos[$j];

      $pdf = new FolhasPresencaPDF("P", "mm", "A4");
      $pdf->ProducePDF("./tmp2/$File_Name", $curso, $orador, $datahora, $situacao, $lista_array, 3);
      $pdf_all->ProducePDFAll("./tmp2/$File_Name", $curso, $orador, $datahora, $situacao, $lista_array, 3);
      echo "<p><a href='$link_email/$_JEI/tmp2/$File_Name '>$curso PDF</a></p>";
      //echo "<p><a href='./tmp2/$File_Name '>PDF</a></p>";

  }
  $t = $participante->getTtableName();
 $File_Name_All = "./tmp2/Presencas_All_$t.pdf";
 $pdf_all->Output($File_Name_All, "F");


  //if ($reg === 1)
      $acccess->listAllHTML();

  ?>

