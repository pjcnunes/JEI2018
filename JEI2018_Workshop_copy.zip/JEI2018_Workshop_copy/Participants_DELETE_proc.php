<!DOCTYPE html>
<html lang="pt">
<head>
	<?php include('head.php'); ?>
  <link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" type="text/css" href="css/estilos_lista.css">
</head>
<body>
	<div id='pagina'>
		<div id='cabecalho'>
			<?php include('cabecalho.php'); ?>
		</div>		
		<div id='menu'>
			<?php include('menu.php'); ?>
		</div>	
		<div id='conteudo'>
			<h1>Lista de Participantes</h1>
  
  <?php
	require_once('InputValidation/CBaseFormValidation.php');
	
	$ID = $_REQUEST['ID'];
	$dbName =  'jei2017_php_mysql'; 'test';
  $dbPass = '';
  $dbUser = 'root';
  $dbHost = 'localhost';
  $dbPort = '3306';
	$dbTableName = 'participantes';
	
		try {
        $options = array(1002 => 'SET NAMES UTF8');
        $ligacao = new PDO("mysql:host={$dbHost}; dbname={$dbName}; port={$dbPort}", $dbUser, $dbPass, $options);
				$ligacao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $pe) {
        echo($pe->getMessage());
    }

		try {
      $sql = "delete from $dbTableName WHERE ID = :ID";
      $stmt = $ligacao->prepare($sql);
			$stmt->bindParam(':ID', $ID);
      $stmt->execute();
			echo "<p>Inscrição eliminada.</p>";
		  echo "<p><a href='Participants_lista.php'><input type='button' class='btn' value='Voltar à lista' /></a></p>";						
    } catch (PDOException $e) {
        $e->getMessage();
    }
  ?>
</body>
</html>
