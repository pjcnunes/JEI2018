<!DOCTYPE html>
<html lang="pt">
<head>
    <?php include('head.php'); ?>
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
    <link rel="stylesheet" type="text/css" href="css/estilos_lista.css">
</head>
<body>
<div id='pagina'>
    <div id='cabecalho'>
        <?php include('cabecalho.php'); ?>
    </div>
    <div id='menu'>
        <?php include('menu.php'); ?>
    </div>
    <div id='conteudo' text-align: center
    '>
    <h1>Lista de Participantes</h1>
    <?php

    $dbName = 'jei2017_php_mysql';
    $dbPass = '';
    $dbUser = 'root';
    $dbHost = 'localhost';
    $dbPort = '3306';
    $dbTableName = 'participantes';

    try {
        $options = array(1002 => 'SET NAMES UTF8');
        $ligacao = new PDO("mysql:host={$dbHost}; dbname={$dbName}; port={$dbPort}", $dbUser, $dbPass, $options);
        $ligacao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $pe) {
        echo($pe->getMessage());
    }

    $where = '';
    $op = '?op=ALL';
    if (isset($_GET['op'])) {
        $op = 'A';
        if ($_GET['op'] == 'C') {
            $where = "where SituacaoInscricao = 'CONFIRMADA'";
            $op = '?op=C';
        } else if ($_GET['op'] == 'NC') {
            $where = "where SituacaoInscricao = 'NAO CONFIRMADA'";
            $op = '?op=NC';
        }
    }

    $sql = "SELECT * FROM $dbTableName $where order by data_inscricao desc";

    $stmt = $ligacao->prepare($sql);
    $res = $stmt->execute();

    $data = date("Y/m/d G:i:s", time());
    echo "<h2>$data</h2>";

    if ($stmt->rowCount() > 0) {
        //fetch records

        echo "<p><a href='FolhasPresencaPDF.php$op'>PDF</a></p>";

        echo "<h2>" . "Total de Inscritos: {$stmt->rowCount()}</h2>";
        echo "<table class='lista' style='text-align: center; width: 95%; margin: auto'><tr>";
        echo "<th class='lista'></th>";
        echo "<th class='lista'></th>";
        echo "<th class='lista'>ID</th>";
        echo "<th class='lista'>Data</th>";
        echo "<th class='lista'>Nome</th>";
        echo "<th class='lista'>Email</th>";
        echo "<th class='lista'>Telemóvel</th>";
        echo "<th class='lista'>Ano</th>";
        echo "<th class='lista'>Curso</th>";
        echo "<th class='lista'>Situação  Participants_lista.php</th>";
        echo '</tr>';

        while ($obj_data = $stmt->fetch(PDO::FETCH_OBJ)) {
            echo '<tr>';

            echo "<td class='lista'><a href='Participants_EDIT_DELETE.php?ID={$obj_data->ID}&op=edit'><img class='botao' src='buttons/edit.png'></a></td>";
            echo "<td class='lista'><a href='Participants_EDIT_DELETE.php?ID={$obj_data->ID}&op=delete'><img class='botao' src='buttons/delete.png'></a></td>";
            echo "<td class='lista'>{$obj_data->ID}</td>";
            echo "<td class='lista'>{$obj_data->SUBMIT_DATE}</td>";
            echo "<td class='lista'>{$obj_data->NomeCompleto}</td>";
            echo "<td class='lista'>{$obj_data->Email}</td>";
            echo "<td class='lista'>{$obj_data->Telemovel}</td>";
            echo "<td class='lista'>{$obj_data->Ano}</td>";
            echo "<td class='lista'>{$obj_data->Escola}</td>";

            if ($obj_data->SituacaoInscricao == 'CONFIRMADA') {
                $ok = 'cancel';
                $ok2 = 'ok';
            } else {
                $ok = 'ok';
                $ok2 = 'cancel';
            }
            echo "<th class='lista'><a href='Participants_Confirm.php?ref={$obj_data->ReferenciaConfirmacao}&sit=$ok'><img class='botao' src='buttons/$ok2.png'></a></th>";
            echo '<tr>';
        }
        echo '<tr>';
    } else {
        print "No rows matched the query.";
    }
    ?>
    </table>
</div>
<div id='rodape'>
    <?php include('rodape.php'); ?>
</div>
</div>
</body>
</html>