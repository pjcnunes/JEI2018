<?php
/**
 * Created by PhpStorm.
 * User: pnunes
 * Date: 17/04/2018
 * Time: 17:33
 */

?>
<h1>Formulário de inscrição</h1>
<form name='Participants' method='POST' enctype='multipart/form-data'
      action='Inscricao_proc.php'>
    <p>Nome Completo</p>
    <input type='text' name='NomeCompleto' value="Ana Gomes" required />
    <p>EMail</p>
    <input type='email' name='EMail' value="agomes@ipg.pt" required />
    <p><input type='submit' class="btn" value='Enviar'/></p>
</form>